<?php
ob_start();
header("location:./admin");
ob_flush();